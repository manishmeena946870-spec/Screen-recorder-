package com.example.screenrec

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var timer: TextView
    private lateinit var status: TextView
    private lateinit var label: TextView
    private lateinit var button: FrameLayout
    private lateinit var mic: Switch

    private val ui = Handler(Looper.getMainLooper())
    private var wasRecording = false
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 400)
        }
    }

    private val bg = Color.parseColor("#0F1115")
    private val card = Color.parseColor("#1A1D24")
    private val gray = Color.parseColor("#8A92A0")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun circle(fill: Int, ring: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(fill)
        setStroke(dp(6), ring)
    }

    private fun spacer() = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(bg)
            setPadding(dp(24), dp(48), dp(24), dp(32))
        }

        val title = TextView(this).apply {
            text = "Screen Recorder"
            textSize = 20f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)
        root.addView(spacer())

        timer = TextView(this).apply {
            text = "00:00"
            textSize = 64f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        root.addView(timer)

        status = TextView(this).apply {
            text = "Ready to record"
            textSize = 15f
            setTextColor(gray)
            setPadding(0, dp(4), 0, dp(32))
        }
        root.addView(status)

        label = TextView(this).apply {
            text = "START"
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        button = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(150), dp(150))
            background = circle(Color.parseColor("#E53935"), Color.parseColor("#55E53935"))
            isClickable = true
            setOnClickListener { onRecordClick() }
            addView(label, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            ))
        }
        root.addView(button)
        root.addView(spacer())

        val hint = TextView(this).apply {
            text = "Tap START, then go to the screen you want to record."
            textSize = 13f
            setTextColor(gray)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(16))
        }
        root.addView(hint)

        mic = Switch(this).apply { isChecked = true }
        val micRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(card, 16)
            setPadding(dp(18), dp(14), dp(18), dp(14))
            addView(TextView(context).apply {
                text = "Record mic audio"
                textSize = 16f
                setTextColor(Color.WHITE)
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(mic)
        }
        root.addView(micRow, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        val play = TextView(this).apply {
            text = "Play last recording"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = rounded(card, 16)
            setPadding(dp(18), dp(16), dp(18), dp(16))
            setOnClickListener { playLast() }
        }
        val playLp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        playLp.topMargin = dp(12)
        root.addView(play, playLp)

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        wasRecording = RecorderService.recording
        ui.post(tick)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
    }

    private fun refresh() {
        val rec = RecorderService.recording
        if (rec) {
            val s = (SystemClock.elapsedRealtime() - RecorderService.startedAt) / 1000
            timer.text = String.format("%02d:%02d", s / 60, s % 60)
            status.text = "Recording..."
            label.text = "STOP"
            button.background = circle(Color.parseColor("#7A1F1C"), Color.WHITE)
        } else {
            timer.text = "00:00"
            if (wasRecording) {
                status.text = "Saved in Movies/ScreenRecorder"
            } else if (status.text == "Recording...") {
                status.text = "Ready to record"
            }
            label.text = "START"
            button.background = circle(Color.parseColor("#E53935"), Color.parseColor("#55E53935"))
        }
        wasRecording = rec
    }

    private fun onRecordClick() {
        if (RecorderService.recording) {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
            return
        }
        val need = mutableListOf<String>()
        if (mic.isChecked &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.POST_NOTIFICATIONS)

        if (need.isEmpty()) askCapture() else requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (mic.isChecked &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) {
            mic.isChecked = false
            Toast.makeText(this, "Mic permission denied. Recording without mic.", Toast.LENGTH_LONG).show()
        }
        askCapture()
    }

    private fun askCapture() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 2)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, RecorderService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
                .putExtra("mic", mic.isChecked)
            startForegroundService(i)
        }
    }

    private fun latestRecording(): Uri? {
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        contentResolver.query(
            collection,
            arrayOf(MediaStore.Video.Media._ID),
            MediaStore.Video.Media.RELATIVE_PATH + " LIKE ?",
            arrayOf("%ScreenRecorder%"),
            MediaStore.Video.Media.DATE_ADDED + " DESC"
        )?.use { c ->
            if (c.moveToFirst()) return ContentUris.withAppendedId(collection, c.getLong(0))
        }
        return null
    }

    private fun playLast() {
        val u = latestRecording()
        if (u == null) {
            Toast.makeText(this, "No recordings yet", Toast.LENGTH_SHORT).show()
            return
        }
        val view = Intent(Intent.ACTION_VIEW)
            .setDataAndType(u, "video/mp4")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(view, "Play with"))
    }
}
